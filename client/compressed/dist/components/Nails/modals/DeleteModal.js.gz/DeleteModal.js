import React from 'react';

const DeleteModal = () => {
  return <div>DeleteModal</div>;
};

export default DeleteModal;
