import React, { useEffect } from 'react';

export const disabledDays = [];

// { year: 2022, month: 4, day: 2 },
//   { year: 2022, month: 4, day: 9 },
//   { year: 2022, month: 4, day: 16 },
//   { year: 2022, month: 4, day: 23 },
//   { year: 2022, month: 4, day: 30 },
