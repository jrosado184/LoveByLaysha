export const THEME = 'THEME';

export const getTheme = () => {
  return { type: THEME };
};
