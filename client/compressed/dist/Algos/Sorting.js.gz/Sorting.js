const dummyData = [
  {
    appointment_date: {
      appointment_day: 11,
      appointment_month: "May",
      appointment_year: 2022,
    },
  },
  {
    appointment_date: {
      appointment_day: 2,
      appointment_month: "December",
      appointment_year: 2022,
    },
  },
  {
    appointment_date: {
      appointment_day: 1,
      appointment_month: "June",
      appointment_year: 2022,
    },
  },
];

export const sortDates = () => {
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
};
